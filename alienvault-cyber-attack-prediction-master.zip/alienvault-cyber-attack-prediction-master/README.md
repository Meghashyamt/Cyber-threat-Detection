Uses ML to try and predict cyber attacks using AlienVault OTX threat intel.

Read the paper titled "AlienVault OTX Cyber Attack Prediction -  Cody Brown.pdf" for more info.